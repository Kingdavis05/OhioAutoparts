import React, { useState } from "react";
import { useLocation } from "react-router-dom";

export default function Checkout() {
  const { state } = useLocation();
  const cart = state?.cart || [];
  const [customer, setCustomer] = useState({ name: "", email: "", address: "" });
  const [message, setMessage] = useState("");

  const placeOrder = async () => {
    try {
      const res = await fetch(
        "https://ohio-auto-backend.onrender.com/api/orders",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ customer, cart, paymentMethodId: "pm_card_visa" })
        }
      );
      const data = await res.json();
      if (data.success) {
        setMessage("Order placed successfully!");
      } else {
        setMessage("Order failed: " + data.error);
      }
    } catch (err) {
      setMessage("Error: " + err.message);
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Checkout</h1>
      <div>
        <input
          placeholder="Name"
          value={customer.name}
          onChange={(e) => setCustomer({ ...customer, name: e.target.value })}
        />
        <input
          placeholder="Email"
          value={customer.email}
          onChange={(e) => setCustomer({ ...customer, email: e.target.value })}
        />
        <input
          placeholder="Address"
          value={customer.address}
          onChange={(e) => setCustomer({ ...customer, address: e.target.value })}
        />
      </div>
      <button onClick={placeOrder}>Submit Order</button>
      <p>{message}</p>
    </div>
  );
}