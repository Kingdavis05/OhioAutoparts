import React, { useState } from "react";
import { Link } from "react-router-dom";

const sampleProducts = [
  { id: 1, name: "Brake Pads", price: 50 },
  { id: 2, name: "Oil Filter", price: 20 },
  { id: 3, name: "Spark Plug", price: 10 }
];

export default function Home() {
  const [cart, setCart] = useState([]);

  const addToCart = (p) => {
    setCart([...cart, { ...p, quantity: 1 }]);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Ohio Auto Parts</h1>
      <h2>Products</h2>
      <ul>
        {sampleProducts.map((p) => (
          <li key={p.id}>
            {p.name} - ${p.price}{" "}
            <button onClick={() => addToCart(p)}>Add</button>
          </li>
        ))}
      </ul>
      <h3>Cart: {cart.length} items</h3>
      <Link to="/checkout" state={{ cart }}>
        <button>Checkout</button>
      </Link>
    </div>
  );
}