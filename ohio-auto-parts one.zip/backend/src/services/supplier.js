import axios from "axios";

export async function placeOrderWithSupplier(cart, customer) {
  try {
    const res = await axios.post(
      `${process.env.SUPPLIER_API_BASE}/orders`,
      { cart, customer },
      { headers: { Authorization: `Bearer ${process.env.SUPPLIER_API_KEY}` } }
    );
    console.log("Supplier order placed:", res.data);
    return res.data;
  } catch (err) {
    console.error("Supplier order failed", err.message);
    throw err;
  }
}