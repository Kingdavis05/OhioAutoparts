import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: false,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
});

export async function sendOrderEmail(to, orderId) {
  await transporter.sendMail({
    from: process.env.SMTP_FROM,
    to,
    subject: `Your Ohio Auto Parts Order #${orderId}`,
    text: `Thank you for your order! Your order number is ${orderId}. We will notify you when it ships.`
  });
  console.log("Email sent to", to);
}