import express from "express";
import bodyParser from "body-parser";
import dotenv from "dotenv";
import Stripe from "stripe";
import pkg from "pg";
import { placeOrderWithSupplier } from "./services/supplier.js";
import { sendOrderEmail } from "./services/email.js";

dotenv.config();
const app = express();
const port = process.env.PORT || 4000;
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const { Pool } = pkg;

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL.includes("localhost") ? false : { rejectUnauthorized: false }
});

app.use(bodyParser.json());

app.post("/api/orders", async (req, res) => {
  try {
    const { customer, cart, paymentMethodId } = req.body;

    const custRes = await pool.query(
      "INSERT INTO customers (name, email, address) VALUES ($1,$2,$3) RETURNING id",
      [customer.name, customer.email, customer.address]
    );
    const customerId = custRes.rows[0].id;

    const orderRes = await pool.query(
      "INSERT INTO orders (customer_id, status) VALUES ($1,'pending') RETURNING id",
      [customerId]
    );
    const orderId = orderRes.rows[0].id;

    for (let item of cart) {
      await pool.query(
        "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ($1,$2,$3,$4)",
        [orderId, item.id, item.quantity, item.price]
      );
    }

    const paymentIntent = await stripe.paymentIntents.create({
      amount: cart.reduce((t, i) => t + i.price * i.quantity, 0) * 100,
      currency: "usd",
      payment_method: paymentMethodId,
      confirm: true
    });

    await pool.query("UPDATE orders SET status='paid' WHERE id=$1", [orderId]);

    await placeOrderWithSupplier(cart, customer);
    await sendOrderEmail(customer.email, orderId);

    res.json({ success: true, orderId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Order failed" });
  }
});

app.listen(port, () => {
  console.log(`Backend running on port ${port}`);
});