# Ohio Auto Parts

## Deploy

Backend:
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)

Frontend:
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

---
1. Copy `.env.example` → `.env` and fill in Stripe, SendGrid, Supplier API keys on Render.
2. Apply `schema.sql` to your Postgres database.
3. Deploy frontend with Vercel and backend with Render.
